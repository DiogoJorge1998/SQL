select * from compositor 
where nome like 'a%' or nome like '%a';