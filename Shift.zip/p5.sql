SELECT * 
FROM compositor 
WHERE morada like 'Estados Unidos%' 
or morada like '%Estados Unidos%' 
or morada like '%Estados Unidos' 