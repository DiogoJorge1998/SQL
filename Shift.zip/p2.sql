select count(funcionario.nome)
from funcionario, musica
where funcionario.nome = musica.artista;