import java.sql.*;

public class SQL {
	private Connection con;
	private Statement s;
	private ResultSet rs;
	//The constructor
	public SQL() {}
	
	//Commands
	public void connect(String host, String username, String password) throws Exception{
	    String driver = "com.mysql.jdbc.Driver";
	    
	       try {
	           Class.forName(driver);
	        }
	        catch (ClassNotFoundException e) {
	          e.printStackTrace();
	          System.err.println("Cannot load driver " + e.getMessage());
	          System.exit(1);
	        }
	    
		try {
			this.con = DriverManager.getConnection( host, username, password);
		}
		catch(SQLException connectionFailed) {
			throw new Exception("Nao foi possivel efetuar a coneccao!");
		}
		System.out.println("Coneccao bem sucedida!");
	}
	
	public void createStatement() throws SQLException {
		this.s = this.con.createStatement();
	}
	
	public void ExecuteStatement(String input) throws SQLException {
		this.con.prepareStatement(input);
		this.rs = this.s.executeQuery(input);
	}
	
	public void showResultCommand() throws SQLException {
			//System.out.println(rs.getMetaData());
		ResultSetMetaData metadata = rs.getMetaData();
		System.out.println("");
		   for(int j = 1; j <= metadata.getColumnCount(); j++)
			   System.out.print(metadata.getColumnName(j)+", ");
		   System.out.println("");
		   System.out.println("");
		   while (rs.next()) {
			   for (int i = 1; i <= metadata.getColumnCount(); i++) {
		           if (i > 1) System.out.print("	");
		           System.out.print(rs.getString(i));
		       }
		       System.out.println("");
		   }
	       System.out.println("");
	}
	public ResultSetMetaData getMD(String table) throws SQLException {
		this.createStatement();
		this.rs = this.s.executeQuery("select * from "+table);
		ResultSetMetaData metadata = rs.getMetaData();
		return metadata;
	}
	public void insert(String command) throws SQLException {
		this.s.executeUpdate(command);
	}
	public void delete(String command) throws SQLException {
		this.s.executeUpdate(command);
	}
	public void update() throws SQLException {}
}
