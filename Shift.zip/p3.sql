select 
    musica.id, 
    album.nome, 
    musica.nome 
from 
    musica 
        join album 
            on album.id=musica.id