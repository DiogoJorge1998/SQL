CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(1000) NOT NULL,
  `data_de_criacao` date DEFAULT NULL,
  `artista` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,'Daddy K - The Mix 11','2017-09-12','Michael Dapaah'),(2,'A kind of magic','1986-10-05','Queen'),(3,'News of the world','1977-05-15','Queen'),(4,'The game','1980-08-22','Queen'),(5,'Imagine','1971-04-12','John Lennon');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compositor`
--

DROP TABLE IF EXISTS `compositor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compositor` (
  `Nome` varchar(1000) NOT NULL,
  `data de criacao` date DEFAULT NULL,
  `Morada` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='			';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compositor`
--

LOCK TABLES `compositor` WRITE;
/*!40000 ALTER TABLE `compositor` DISABLE KEYS */;
INSERT INTO `compositor` VALUES ('Antonio Vivaldi','1678-03-04',NULL),('Fernando Correa de Oliveira','1921-11-02',NULL),('Lev Knipper','1898-12-03',NULL),('Paul McCartney','1942-06-18','41 West 54th Street, Nova Iorque, Estados Unidos'),('RedOne','1972-04-09','?, ?, Estados Unidos'),('Samuel Osborne Barber','1910-03-09',NULL);
/*!40000 ALTER TABLE `compositor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estudio`
--

DROP TABLE IF EXISTS `estudio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estudio` (
  `Nome` varchar(1000) NOT NULL,
  `Data de criacao` date NOT NULL,
  `Morada` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estudio`
--

LOCK TABLES `estudio` WRITE;
/*!40000 ALTER TABLE `estudio` DISABLE KEYS */;
INSERT INTO `estudio` VALUES ('Sound Pressure Studios','2009-04-05','Av. da Republica 106, Alges, Portugal'),('Def Jam Recordings','1984-03-01',NULL),('Abbey Road Studios','1931-11-01','3 Abbey Road St Johns Wood, Westminster, Reino Unido'),('Capitol Studios','1956-01-01','1750 North Vine Street, Hollywood, Estados Unidos');
/*!40000 ALTER TABLE `estudio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `Nome` varchar(1000) NOT NULL,
  `data_de_nascimento` date DEFAULT NULL,
  `CV` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES ('Axel Christofer Hedfors','1977-12-18',NULL),('George Harrison','1943-02-25',NULL),('John Lennon','1940-10-09',NULL),('Martim Viana','1998-09-27',NULL),('Michael Dapaah','1991-01-25',NULL),('Nelson Manuel Paulino Rosado','1976-02-03',NULL),('Queen','1970-01-25',NULL),('Sebastian Ingrosso','1983-04-20',NULL),('Sergio Miguel Paulino Rosado','1980-02-22',NULL),('Sir James Paul McCartney','1942-06-18',NULL),('Sir Richard Starkey','1940-06-07',NULL),('Steve Angello Josefsson Fragogiannis','1982-11-22',NULL);
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gravadora`
--

DROP TABLE IF EXISTS `gravadora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gravadora` (
  `Nome` varchar(1000) NOT NULL,
  `Morada` varchar(1000) DEFAULT NULL,
  `data_de_criacao` date DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gravadora`
--

LOCK TABLES `gravadora` WRITE;
/*!40000 ALTER TABLE `gravadora` DISABLE KEYS */;
INSERT INTO `gravadora` VALUES ('Hollywood Records','500 S. Buena Vista Street Burbank, California','1989-05-21'),('Sony Music','25 Madison Avenue, Nova Iorque, Estados Unidos','1929-01-01'),('Universal Music Group','2220 Colorado Avenue, Santa Monica, Estados Unidos','1934-09-01'),('Warner Music Group','1633 Broadway, Nova Iorque, Estados Unidos','1958-01-01');
/*!40000 ALTER TABLE `gravadora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `musica`
--

DROP TABLE IF EXISTS `musica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `musica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(1000) NOT NULL,
  `Duracao` time(5) DEFAULT NULL,
  `Genero` varchar(1000) DEFAULT NULL,
  `artista` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `musica`
--

LOCK TABLES `musica` WRITE;
/*!40000 ALTER TABLE `musica` DISABLE KEYS */;
INSERT INTO `musica` VALUES (1,'Mans not hot','00:04:12.00000','hip-hop / rap','Michael Dapaah'),(2,'We Will Rock You','00:02:14.00000','rock','Queen'),(3,'Princes Of The Universe','00:03:54.00000','rock','Queen'),(4,'Another one bites the dust','00:03:42.00000','rock','Queen'),(5,'Imagine','00:03:53.00000','soft rock / pop','john lennon'),(6,'Laktos','00:02:49.00000','house','Sebastian Ingrosso'),(7,'Reload','00:06:02.00000','Progressive house','Sebastian Ingrosso');
/*!40000 ALTER TABLE `musica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtora`
--

DROP TABLE IF EXISTS `produtora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtora` (
  `Nome` varchar(1000) NOT NULL,
  `Morada` varchar(1000) DEFAULT NULL,
  `data_de_criacao` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtora`
--

LOCK TABLES `produtora` WRITE;
/*!40000 ALTER TABLE `produtora` DISABLE KEYS */;
INSERT INTO `produtora` VALUES ('Anjos','Rua Almada Negreiros 389, Fernao Ferro, Portugal','1996-01-01'),('Axwell','Lund, Suecia','1977-12-18'),('David Bowie',NULL,'1947-01-08'),('Eric Prydz','?, Londres, Reino Unido','2001-01-01'),('Frank Sinatra',NULL,'1915-12-12'),('JAY-Z','195 Hudson Street Nova Iorque, Estados Unidos','1969-12-4'),('Orquestra Sinfonica de Londres','Silk Street, Londres, Reino Unido','1904-01-01'),('Orquestra Sinfonica de Moscovo','Mosfilmovskaya , Moscovo, Russia','1989-01-01'),('Sebastian Ingrosso','Nacka, Suecia','1983-04-20'),('Swedish House Mafia',NULL,'2005-01-01'),('The Beatles',NULL,'1960-01-01');
/*!40000 ALTER TABLE `produtora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotora`
--

DROP TABLE IF EXISTS `promotora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(1000) NOT NULL,
  `data_de_criacao` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotora`
--

LOCK TABLES `promotora` WRITE;
/*!40000 ALTER TABLE `promotora` DISABLE KEYS */;
INSERT INTO `promotora` VALUES (1,'Jim Aiken','1932-01-01'),(2,'Sidney Bernstein','2013-08-12'),(3,'Peter Bennett','1935-05-10'),(4,'Sharon Osbourne','1952-10-09'),(5,'Marek Lieberberg','1946-05-07');
/*!40000 ALTER TABLE `promotora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-30 14:52:12
