		*F I C H E I R O S*
Main.java: Componente principal do programa
SQL.java: Class onde todas as opera��es que envolvem SQL est�o localizadas
mysql-connector-java-5.1.45-bin: Referenced library necess�ria para a utiliza��o do programa, n�o � preciso realizar quaisquer compila��es ao ficheiro

		*C O M P I L A � � O*
Instru��es: 	*Aceda � linha de comandos ou equivalente em sistemas operativos que n�o s�o windows;
		*Aceda � pasta onde se encontra este ficheiro atrav�s da linha de comandos;
		*escreva 'javac -cp mysql-connector-java-5.1.45-bin Main.java SQL.java' na linha de comandos, no entanto, existe j� um ficheiro compile.bat que executa dentro da pasta;
		*Executa o programa escrevendo 'java -cp .;mysql-connector-java-5.1.45-bin.jar Main', no entanto, existe j� um ficheiro .bat que executa o programa dentro da pasta.

**
Caso pretenda inserir ou apagar dados e seja pedido um elemento no formato VARCHAR,
utilize pelicas entre a palavra (por exemplo: 'palavra')