select funcionario.nome, gravadora.nome, year(data_de_criacao), year(data_de_nascimento) from gravadora, funcionario 
where year(data_de_criacao) = year(data_de_nascimento)