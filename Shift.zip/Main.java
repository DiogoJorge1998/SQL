import java.sql.ResultSetMetaData;
import java.util.*;
//import java.sql.*;


//@Author Diogo Cordeiro, n 57652
//@Author Martim Viana, n 57667
public class Main {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		//Carrega a base de dados
		SQL sql = new SQL();
		
		//Input para conetar a base de dados
		List<String> input = new ArrayList<String>();
		System.out.print("Port: ");
		String port = sc.nextLine();
		System.out.print("Base de dados: ");
		input.add("jdbc:mysql://localhost:"+port+"/"+sc.nextLine());
		System.out.print("Anfitriao: ");
		input.add(sc.nextLine());
		System.out.print("Palavra-passe: ");
		input.add(sc.nextLine());
		
		//Coneta a base de dados
		sql.connect(input.get(0), input.get(1), input.get(2));	//Tries to connect to the database
		String command = "";
		
		//Le o input
		while(!command.equals("sair")) {
			//Imprime o menu
			System.out.println("_____________________________________________________________________________________________________");
			System.out.println("Se quiser desligar o programa, escreva 'sair'. Nao inclua ';' no fim do seu comando.");
			System.out.println("");
			System.out.println("1: Query para encontrar, na tabela 'compositor' todos os nomes come�ados ou acabados na letra 'a'.");
			System.out.println("2: Quantos funcionarios sao artistas musicais?");
			System.out.println("3: A que album pertencem as musicas?");
			System.out.println("4: Quais os funcionarios que nasceram no mesmo ano que a gravadora?");
			System.out.println("5: Adicionar dados.");
			System.out.println("6: Apagar dados.");
			System.out.println("7: Query livre.");
			System.out.println("8: Creditos.");
			System.out.println("");
			
			//As escolhas possiveis do menu
			command = sc.nextLine();
			if(command.equals("7")) {	//Query livre
				System.out.println("Escreva 'sair' para sair do modo 'Query livre'.");
				System.out.println("");
				while(!command.equals("sair")) {
					command = sc.nextLine();
					try {
						sql.createStatement();
						sql.ExecuteStatement(command);
						sql.showResultCommand();
					}
					catch(Exception CommandInvalid) {
						System.out.println("Invalid input!");
					}
				}
			}
			//As queries pre-definidas
			else if(command.equals("1")) {	//1a pergunta da 3a parte
				sql.createStatement();
				sql.ExecuteStatement("select * from compositor where nome like 'a%' or nome like '%a';");
				sql.showResultCommand();
			}
			else if(command.equals("2")) {	//2a pergunta da 3a parte
				sql.createStatement();
				sql.ExecuteStatement("select count(funcionario.nome) from funcionario, musica where funcionario.nome = musica.artista;");
				sql.showResultCommand();
			}
			else if(command.equals("3")) {	//3a pergunta da 3a parte
				sql.createStatement();
				sql.ExecuteStatement("select musica.id, album.nome, musica.nome from musica join album on album.id=musica.id");
				sql.showResultCommand();
			}
			else if(command.equals("4")) {	//4a pergunta da 3a parte
				sql.createStatement();
				sql.ExecuteStatement("select funcionario.nome, gravadora.nome, year(data_de_criacao), year(data_de_nascimento) from gravadora, funcionario where year(data_de_criacao) = year(data_de_nascimento)");
				sql.showResultCommand();
			}
			else if(command.equals("5")) {	//Inserir dados
				System.out.print("Nome da tabela: ");
				String table = sc.nextLine();	//Nome da tabela onde vao ser inseridos os dados
				ResultSetMetaData metadata = sql.getMD(table);
				System.out.println("Nomes das colunas: ");
				System.out.println("Para a tabela '"+table+"', por favor insira no seguinte formato:");
				//Mostra o formato como o input deve ser inserido
				System.out.print("(");
				for(int i = 1; i < metadata.getColumnCount(); i++) {
					if(!metadata.getColumnName(i).equals("id")) {

						System.out.print(metadata.getColumnTypeName(i)+", ");
					}
				}
				System.out.println(metadata.getColumnTypeName(metadata.getColumnCount())+")");
				System.out.println("");
				System.out.println("A tabela possui os seguintes nomes nas colunas:");
				System.out.print("(");
				for(int j = 1; j < metadata.getColumnCount(); j++) {
					if(!metadata.getColumnName(j).equals("id"))  {
			   			System.out.print(metadata.getColumnName(j)+", ");
					}
				}
			   	System.out.println(metadata.getColumnName(metadata.getColumnCount())+")");
			   	System.out.println("");
				//
				command = "INSERT INTO "+table+" VALUES"+sc.nextLine();	//Acaba o comando
				try {
					sql.insert(command);	//Tenta inserir os dados
					System.out.println("dados inseridos com sucesso.");
				}
				catch (Exception badData){
					System.out.println("Nao foi possivel inserir os dados na tabela.");
				}
			}
			else if(command.equals("6")) {	//Apagar os dados
				System.out.println("Tabela: ");
				String table = sc.nextLine();	//Nome da tabela onde vao ser apagados os dados
				System.out.println(sql.getMD(table).getColumnName(1)+": ");
				//Cria o comando baseado 
				command = "DELETE FROM "+table+" WHERE "+sql.getMD(table).getColumnName(1)+"= "+sc.nextLine();
				System.out.println(command);
				try {
					sql.delete(command);
					System.out.println("Dados apagados.");
				}
				catch (Exception cantDelete) {System.out.println("Nao e possivel apagar os dados.");}
			}
			else if(command.equals("8")) {	//Creditos
				System.out.println("Trabalho realizado por:");
				System.out.println("Diogo Cordeiro, 57652");
				System.out.println("Martim Viana, 57667");
			}
			else {System.out.println("Comando inexistente.");}
		}
		//Shuts down program
		sc.close();
	}
}
