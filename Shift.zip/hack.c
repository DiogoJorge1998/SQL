#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <string.h>

void strings_write(FILE *f, const char **s, int n, const char *separator)
{
  if (n > 0)
  {
    fprintf(f, "%s", s[0]);
    for (int i = 1; i < n; i++)  // i = 1
      fprintf(f, "%s%s", separator, s[i]);
  }
}

void print()
{
  int a,b,c,d,e,f,g;
  for (size_t i = 0; i < 100; i++) {
    a = rand() % 10;
    b = rand() % 10;
    c = rand() % 10;
    d = rand() % 10;
    e = rand() % 10;
    f = rand() % 10;
    g = rand() % 10;
    printf( "INSERT INTO website (Nome,Telefone,Regiao)\nVALUES ('test%d', '96%d%d%d%d%d%d%d', 'regiao%d');\n",i,a,b,c,d,e,f,g,i );
}

}

int main()
{
print();
return 0;
}
